function test(sum){
    console.log(sum);
}

function test2(sum){
    console.log(sum*2);
}

function operation(num1,num2,res){
    var sum = num1 + num2
    res(sum);
}
operation(2,3,test);
operation(3,4,test2);


//anagram 
var firstWord = "Deepak";
var secondWord = "Aman";

isAnagram(firstWord, secondWord); // true

function isAnagram(one, two) {
  //Change both words to lowercase for case insensitivity..
  var a = one.toLowerCase();
  var b = two.toLowerCase();

  // Sort the strings, then combine the array to a string. Examine the outcomes.
  a = a.split("").sort().join("");
  b = b.split("").sort().join("");

  console.log("res--------",a,b);

  return a === b;
}

const classDetails = {
    strength: 78,
    benches: 39,
    blackBoard:1,
    address:{
        city:"pune"
    }
  }

  var a= classDetails.strength;
  var b= classDetails.address.city;
console.log("data-------",a,b);

var obj ={firstname:"kalyani",age:23}
console.log(Object.keys(obj));
console.log(Object.values(obj));
console.log(Object.entries(obj));

function* genFunc(){
    yield 3;
    yield 4;
  }
  let res = genFunc();
  console.log(res.next());